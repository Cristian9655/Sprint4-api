package model;

public record Bicicletas (
		Long id,
		String marca,
		String modelo,
		String ano_fabricacao,
		String valor_mercado,
		String num_serie
	
){}