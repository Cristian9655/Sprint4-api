package model;

public record Vistorias (
		Long id,
		String fotos_videos,
		Long id_cliente,
		Long id_bike
		
) {}