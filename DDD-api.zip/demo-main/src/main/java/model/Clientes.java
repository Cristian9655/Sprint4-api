package model;

public record Clientes(
		Long id,
		String nome,
		String telefone,
		String email,
		String cpf
){}
