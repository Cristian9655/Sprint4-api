package service;

import java.util.List;

import data.ClientesDao;
import model.Clientes;


public class ClientesService {
	
	static ClientesDao dao = new ClientesDao();

	public List<Clientes> listarClientes() {
		return dao.listarClientes();
	}
	
	public Clientes consultarClientes(Long id) {
		return dao.consultarClientes(id);
	}
	
	public boolean cadastraClientes(Clientes cliente) {
		if (!validar(cliente)) return false;
		dao.cadastraClientes(cliente);
		return true;
	}
	private boolean validar(Clientes cliente) {
		if (cliente.nome().isEmpty()) return false;
		if (cliente.telefone().isEmpty()) return false;
		if (cliente.email().isEmpty()) return false;
		if (cliente.cpf().isEmpty()) return false;
		
		return true;
	}

	public boolean deletaClientes(Long id) {
		Clientes cliente = dao.consultarClientes(id);

		if (cliente != null) {
			dao.deletaClientes(id);
			return true;
		} else {
			return false;
		}
	}
	
	
}
