# Jersey API Demo

Projeto base da disciplina de DDD com as configurações para acesso a banco de dados Oracle em API REST com Jersey.
